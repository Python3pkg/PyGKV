Uses Git as Key-Value store with a dictionary-like API


